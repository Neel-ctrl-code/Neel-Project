//planet names
var planets = getColumn("Planets of our Solar System", "Planet");
//planet information
var gravity = getColumn("Planets of our Solar System","Gravity");
var distance = getColumn("Planets of our Solar System", "Distance from sun");
var orbitTime = getColumn("Planets of our Solar System", "Orbital period");
var avgTemp = getColumn("Planets of our Solar System", "Mean temperature");
var ring = getColumn("Planets of our Solar System", "Has ring system");
var moonNum = getColumn("Planets of our Solar System", "Number of moons");
var locations = [345,310,275,240,180,100,40,10,-20];
var index = 0;
//list to help filter information
var normal = [planets,gravity,distance,avgTemp,ring,moonNum,orbitTime,locations];

//onEvents for each planets button to set an index and switch screen
onEvent("mercury", "click", function( ) {
  setScreen("screen3");
  index = 0;
  updateScreen();
});

onEvent("venus", "click", function( ) {
  setScreen("screen3");
  index = 1;
  updateScreen();
});

onEvent("earth", "click", function( ) {
  setScreen("screen3");
  index = 2;
  updateScreen();
});

onEvent("mars", "click", function( ) {
  setScreen("screen3");
  index = 3;
  updateScreen();
});

onEvent("jupiter", "click", function( ) {
  setScreen("screen3");
  index = 4;
  updateScreen();
});

onEvent("saturn", "click", function( ) {
  setScreen("screen3");
  index = 5;
  updateScreen();
});

onEvent("uranus", "click", function( ) {
  setScreen("screen3");
  index = 6;
  updateScreen();
});

onEvent("neptune", "click", function( ) {
  setScreen("screen3");
  index = 7;
  updateScreen();
});

onEvent("pluto", "click", function( ) {
  setScreen("screen3");
  index = 8;
  updateScreen();
});

onEvent("locationButton", "click", function( ) {
  setScreen("screen4");
});

onEvent("homeButton", "click", function( ) {
  setScreen("screen1");
});

//function to filter the list and to update the screen
function updateScreen() {
  //if statement to check if everything is valid
  if (index >= 0 && index < planets.length) {
    var filt = [];
    //filters the information into a filtered list
    for (var i = 0; i < planets.length-1; i++) {
     filt[i] = normal[i][index];
     console.log(filt[i]);
    }
    setImageURL("planetPic", planets[index].toLowerCase() + ".png");
    setText("information", "Planet: " + filt[0] + "\nGravity (m/s^2): " + filt[1] + "\nDistance From the Sun (km): " + (filt[2]*1000000).toLocaleString() + "\nAvergae Tempature (C): " + filt[3] + "\nRings: " + filt[4] + "\nHow Many Moons: " + filt[5] + "\nOrbit Time (Days): " + filt[6]);
    setPosition("arrow", 230, filt[7]);
  } else {
    console.log("Invalid index: " + index);
  }
}